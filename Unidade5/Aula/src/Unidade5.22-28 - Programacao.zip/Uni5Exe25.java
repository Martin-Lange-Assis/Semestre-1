
import java.util.Scanner;

public class Uni5Exe25 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int pontoD = 0;
        int pontoE = 0;
        String ponto;

        for (int i = 1; i <= 21; i++) {
            System.out.println("Quem marcou o ponto? ");
            ponto = teclado.next();
            while (ponto == "D") {
                pontoD = pontoD + 1;
                if (pontoD == 21 && pontoD - pontoE >= 2) {
                    System.out.println("O jogador da direita é o vencedor");

                } else {
                    if (pontoD > 21 && pontoD - pontoE == 2) {
                        System.out.println("O jogador da direita é o vencedor");

                    }
                }

            }
            while (ponto == "E") {
                pontoE = pontoE + 1;
                if (pontoE == 21 && pontoE - pontoD >= 2) {
                    System.out.println("O jogador da esquerda é o vencedor");

                } else {
                    if (pontoE > 21 && pontoE - pontoD == 2) {
                        System.out.println("O jogador da esquerda é o vencedor");
                    }
                }

            }
        }
        if (pontoD > pontoE) {
            System.out.println("O jogador da direita é o vencedor");
        } else {
            System.out.println("O jogador da esquerda é o vencedor");
        }

        teclado.close();
    }
}

/*
 * Caro professor,
 * 
 * Se essa mensagem está aparecendo é porque ainda não terminei/fiz o exercício,
 * e muito provavelmente não conseguirei completá - lo até a data/horário
 * limite. Entretanto, farei o meu melhor para solucionar esses problemas e
 * entregar o mais breve possível.
 * 
 * Att.
 * 
 * Martin Lange de Assis
 */