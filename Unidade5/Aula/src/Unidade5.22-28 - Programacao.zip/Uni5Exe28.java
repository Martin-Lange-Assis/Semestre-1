import java.util.Scanner;

public class Uni5Exe28 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int nenhumDeNos = 0;
        int cpm22 = 0;
        int skank = 0;
        int jotaQuest = 0;
        String votoDesejo = " ";
        double percentual1;
        double percentual2;
        double percentual3;
        double percentual4;
        int voto = 0;

        System.out.println("Deseja votar?(s ou n) ");
        votoDesejo = teclado.next();

        while (!votoDesejo.equals("n")) {
            while (votoDesejo.equals("s")) {
                System.out.println("Informe o voto: ");
                voto = teclado.nextInt();
                while (voto == 1) {
                    nenhumDeNos += 1;
                    System.out.println("Mais um voto? (s ou n)");
                    votoDesejo = teclado.next();
                    if (votoDesejo == "s") {
                        nenhumDeNos += 1;
                    } else {
                        if (votoDesejo == "n") {
                            break;
                        }
                    }
                }
                while (voto == 2) {
                    cpm22 += 1;
                    System.out.println("Mais um voto? (s ou n)");
                    votoDesejo = teclado.next();
                    if (votoDesejo == "s") {
                        cpm22 += 1;
                    } else {
                        if (votoDesejo == "n") {
                            break;
                        }
                    }
                }
                while (voto == 3) {
                    skank += 1;
                    System.out.println("Mais um voto? (s ou n)");
                    votoDesejo = teclado.next();
                    if (votoDesejo == "s") {
                        skank += 1;
                    } else {
                        if (votoDesejo == "n") {
                            break;
                        }
                    }
                }
                while (voto == 4) {
                    jotaQuest += 1;
                    System.out.println("Mais um voto? (s ou n)");
                    votoDesejo = teclado.next();
                    if (votoDesejo == "s") {
                        jotaQuest += 1;
                    } else {
                        if (votoDesejo == "n") {
                            break;
                        }
                    }
                }

            }
            percentual1 = nenhumDeNos * 100 / (nenhumDeNos + cpm22 + skank + jotaQuest);
            percentual2 = cpm22 * 100 / (nenhumDeNos + cpm22 + skank + jotaQuest);
            percentual3 = skank * 100 / (nenhumDeNos + cpm22 + skank + jotaQuest);
            percentual4 = jotaQuest * 100 / (nenhumDeNos + cpm22 + skank + jotaQuest);

            System.out.println("O total de votos para o grupo 'Nenhum de Nós' foi de: " + nenhumDeNos + " votos "
                    + " e o " + " percentual foi de " + percentual1);
            System.out.println("O total de votos para o grupo 'CPM22' foi de: " + cpm22 + " votos " + " e o "
                    + " percentual foi de " + percentual2);
            System.out.println("O total de votos para o grupo 'Skank' foi de: " + skank + " votos " + " e o "
                    + " percentual foi de " + percentual3);
            System.out.println("O total de votos para o grupo 'Jota Quest' foi de: " + jotaQuest + " votos " + " e o "
                    + " percentual foi de " + percentual4);

            if (percentual1 > percentual2 && percentual1 > percentual3 && percentual1 > percentual4) {
                System.out.println("Nenhum de Nós é o Vencedor!");
            }
            if (percentual2 > percentual1 && percentual2 > percentual3 && percentual2 > percentual4) {
                System.out.println("CPM22 é o Vencedor!");
            }
            if (percentual3 > percentual2 && percentual3 > percentual1 && percentual3 > percentual4) {
                System.out.println("Skank é o Vencedor!");
            }
            if (percentual4 > percentual2 && percentual4 > percentual3 && percentual4 > percentual1) {
                System.out.println("Jota Quest é o Vencedor!");
            }

        }
        teclado.close();
    }
}

/*
 * Caro professor,
 * 
 * Se essa mensagem está aparecendo é porque ainda não terminei/fiz o exercício,
 * e muito provavelmente não conseguirei completá - lo até a data/horário
 * limite. Entretanto, farei o meu melhor para solucionar esses problemas e
 * entregar o mais breve possível.
 * 
 * Att.
 * 
 * Martin Lange de Assis
 */