import java.util.Scanner;

public class Uni5Exe27 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double dia = 1;
        int totalPecasManha;
        int totalPecasTarde;
        int totalPecasDia;
        double salario = 0;
        String novoFunc = " ";

        System.out.println("Novo funcionário(1.sim 2.não)? ");
        novoFunc = teclado.next();

        while (!novoFunc.equals("n")) {

            for (; dia < 40; dia++) {
                System.out.println("Informe o dia: ");
                dia = teclado.nextInt();
                if (dia < 1 || dia > 30) {
                    System.out.println("Dia Inválido");
                }
                while (dia >= 1 && dia <= 30 && novoFunc.equals("s")) {
                    System.out.println("Informe o total de peças produzidas no período da manhã:");
                    totalPecasManha = teclado.nextInt();
                    System.out.println("Informe o total de peças produzidas no período da tarde: ");
                    totalPecasTarde = teclado.nextInt();
                    totalPecasDia = totalPecasManha + totalPecasTarde;
                    if (dia >= 1 && dia <= 15 && totalPecasDia >= 100 && totalPecasManha >= 30
                            && totalPecasTarde >= 30) {
                        salario = 0.8 * totalPecasDia;
                        System.out.println("O salário do funcionário no dia: " + dia + " foi de R$ " + salario);
                    } else {
                        salario = 0.5 * totalPecasDia;
                        System.out.println("O salário do funcionário no dia: " + dia + " foi de R$ " + salario);
                    }
                    if (dia >= 16 && dia <= 30) {
                        salario = (0.4 * totalPecasManha) + (0.3 * totalPecasTarde);
                        System.out.println("O salário do funcionário no dia: " + dia + " foi de R$ " + salario);

                    }

                }
                System.out.println("Novo funcionário(1.sim 2.não)? ");
                novoFunc = teclado.next();
                if (novoFunc.equals("n")) {
                    break;
                }

            }

            teclado.close();
        }
    }
}

/*
 * Caro professor,
 * 
 * Se essa mensagem está aparecendo é porque ainda não terminei/fiz o exercício,
 * e muito provavelmente não conseguirei completá - lo até a data/horário
 * limite. Entretanto, farei o meu melhor para solucionar esses problemas e
 * entregar o mais breve possível.
 * 
 * Att.
 * 
 * Martin Lange de Assis
 */
