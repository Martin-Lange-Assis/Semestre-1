import java.util.Scanner;

public class Uni5Exe31 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numero;

        System.out.println("Informe um número inteiro: ");
        numero = teclado.nextInt();

        while (numero > 1) {
            for (int i = 2; i < numero; i++) {
                if (numero % i == 0) {
                    System.out.println(i);
                }
                numero = numero / i;
            }
        }

        teclado.close();
    }
}
/*
 * Caro professor,
 * 
 * Se essa mensagem está aparecendo é porque ainda não terminei/fiz o exercício,
 * e muito provavelmente não conseguirei completá - lo até a data/horário
 * limite. Entretanto, farei o meu melhor para solucionar esses problemas e
 * entregar o mais breve possível.
 * 
 * Att.
 * 
 * Martin Lange de Assis
 */