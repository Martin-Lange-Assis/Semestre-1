import java.util.Scanner;

public class Uni5Exe33 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int voto = 1;
        int candidato1 = 1;
        int candidato2 = 1;
        int candidato3 = 1;
        int candidato4 = 1;
        int nulo = 1;
        int branco = 1;

        do {
            System.out.println("Informe o número do candidato: ");
            voto = teclado.nextInt();
            if (voto == 1) {
                candidato1++;

            }

            if (voto == 2) {
                candidato2++;

            }
            if (voto == 3) {
                candidato3++;
            }

            if (voto == 4) {
                candidato4++;
            }

            if (voto == 5) {
                nulo++;

            }
            if (voto == 6) {
                branco++;

            }
            System.out.println("O total de votos do candidato 1 é:" + candidato1);
            System.out.println("O total de votos do candidato 2 é:" + candidato2);
            System.out.println("O total de votos do candidato 3 é:" + candidato3);
            System.out.println("O total de votos do candidato 4 é:" + candidato4);
            System.out.println("O total de votos do candidato 5 é:" + nulo);
            System.out.println("O total de votos do candidato 6 é:" + branco);

            if (voto != 1 || voto != 2 || voto != 3 || voto != 4 || voto != 5 || voto != 6) {
                System.out.println("Opção Incorreta");

            }

        } while (voto == 0);

        teclado.close();
    }
}

/*
 * Caro professor,
 * 
 * Se essa mensagem está aparecendo é porque ainda não terminei/fiz o exercício,
 * e muito provavelmente não conseguirei completá - lo até a data/horário
 * limite. Entretanto, farei o meu melhor para solucionar esses problemas e
 * entregar o mais breve possível.
 * 
 * Att.
 * 
 * Martin Lange de Assis
 */
