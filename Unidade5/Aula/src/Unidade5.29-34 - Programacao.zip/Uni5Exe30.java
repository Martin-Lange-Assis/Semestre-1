import java.util.Scanner;

public class Uni5Exe30 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        /*
         * Caro professor,
         * 
         * Se essa mensagem está aparecendo é porque ainda não terminei/fiz o exercício,
         * e muito provavelmente não conseguirei completá - lo até a data/horário
         * limite. Entretanto, farei o meu melhor para solucionar esses problemas e
         * entregar o mais breve possível.
         * 
         * Att.
         * 
         * Martin Lange de Assis
         */

        teclado.close();
    }
}
