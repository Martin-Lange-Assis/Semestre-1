public class Uni5Exe11 {
    public static void main(String[] args) {
        int qtdBiscoito;

        for (int i = 1; i <= 16; i++) {
            qtdBiscoito = 3 * i;
            i++;
            System.out.println(qtdBiscoito);

        }
    }
}
