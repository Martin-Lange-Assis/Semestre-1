public class Uni5Exe03 {
    public static void main(String[] args) {
        double somaTermos = 0;

        for (double i = 1; i <= 100; i++) {
            somaTermos += 1 / i;

        }
        System.out.println("A soma dos termos será " + somaTermos);

    }
}
